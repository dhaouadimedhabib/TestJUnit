package com.esprit.microservices.candidate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atelier1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
